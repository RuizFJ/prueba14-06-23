package prueba;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class proce1 {
	
	Scanner tc = new Scanner(System.in);
	
	
	int  arrayn2 [] = new int [100];
	int n = 0;
	int numeros,numeros2;
	int suma,contador,mostrar;
	float media;
	
	public void rellenar() {
		System.out.println("Ingrese la cantidad de elementos que desea ingresar");
		n= tc.nextInt();
		ArrayList<Integer> array = new ArrayList<>(n);
		
		for (int i=0;i<n;i++) {
			
			System.out.println("Ingrese el numero "+(i+1));
			numeros=tc.nextInt();
			if (numeros!=-99) {
				array.add(numeros);
				arrayn2[i]=numeros;
				contador++;
				suma= suma+arrayn2[i];
				
				
			} else {
				break;
			}
		}
			
		
		media=(float) suma/(contador);
		System.out.println("Los numeros mayores que la media son ");
		
		
		
		for (int i = 0; i < arrayn2.length; i++) {
			if (arrayn2[i]>media) {
				mostrar = arrayn2[i];
				System.out.println(mostrar);
				
			}
			
		}
		
		
		
		
		
		
			
		
		
		System.out.println("El array list es "+array);
		
	}
	
	public void suma() {
for (int i=0;i<n;i++) {
			
			
			if (numeros!=-99) {
				
				arrayn2[i]=numeros;
				contador++;
				suma= suma+arrayn2[i];
				
				
			} else {
				break;
			}
		}

System.out.println("La suma de los elementos es "+suma+"\nLa media es "+media);


		
	}
	
	
}

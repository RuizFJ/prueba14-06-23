package prueba;

import java.util.ArrayList;

public class arraylist {

	public static void main(String[] args) {
		
		
		try {
		
		proce1 op = new proce1();
		
		
	op.rellenar();	
	op.suma();	
		
		
		
		} catch (java.util.InputMismatchException e) {
			System.out.println("Error dato invalido");
		}
		
		
		
		
		

	}

}
